<?php
/**
 * Plugin Name: For Kannada Lesson Fields
 * Description: Adds a dedicated Kannada Heading field to Lesson posts and exposes it to the REST API.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', function () {
    register_post_meta('lesson', 'kannada_heading', [
        'single' => true,
        'type' => 'string',
        'show_in_rest' => true,
        'sanitize_callback' => 'sanitize_text_field',
        'auth_callback' => function () {
            return current_user_can('edit_posts');
        },
    ]);
});

add_action('add_meta_boxes_lesson', function () {
    add_meta_box(
        'for_kannada_heading',
        __('Kannada Heading', 'for-kannada'),
        'for_kannada_render_heading_box',
        'lesson',
        'normal',
        'high'
    );
});

function for_kannada_render_heading_box($post) {
    wp_nonce_field('for_kannada_save_heading', 'for_kannada_heading_nonce');
    $value = get_post_meta($post->ID, 'kannada_heading', true);
    ?>
    <p style="margin-top:0;">
        <label for="for_kannada_heading_field"><?php esc_html_e('Short Kannada heading for the card display.', 'for-kannada'); ?></label>
    </p>
    <input
        type="text"
        id="for_kannada_heading_field"
        name="for_kannada_heading_field"
        value="<?php echo esc_attr($value); ?>"
        style="width:100%;max-width:640px;"
        placeholder="e.g. Chitte"
    />
    <?php
}

add_action('save_post_lesson', function ($post_id) {
    if (!isset($_POST['for_kannada_heading_nonce']) || !wp_verify_nonce($_POST['for_kannada_heading_nonce'], 'for_kannada_save_heading')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['for_kannada_heading_field'])) {
        update_post_meta(
            $post_id,
            'kannada_heading',
            sanitize_text_field(wp_unslash($_POST['for_kannada_heading_field']))
        );
    }
});
