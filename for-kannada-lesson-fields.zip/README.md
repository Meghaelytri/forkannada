# For Kannada Lesson Fields

This plugin adds a dedicated `kannada_heading` field to the `lesson` post type and exposes it through the WordPress REST API.

## What it does

- Adds a `Kannada Heading` box for Lesson posts
- Saves the value as post meta
- Makes it available in REST responses as `meta.kannada_heading`

## Install

1. Copy this folder into your WordPress plugins directory.
2. Activate the plugin.
3. Edit a Lesson and fill in the Kannada Heading field.

## Frontend mapping

The Next.js app reads `lesson.meta.kannada_heading` and uses it on the lesson card.
